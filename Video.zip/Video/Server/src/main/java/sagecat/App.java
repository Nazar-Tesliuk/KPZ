package sagecat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;       
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Server app for a VideoSurveillanceApp due to software architecture
 *
 */
public class App 
{
    private static final ReadWriteLock readWriteLock = new ReentrantReadWriteLock();
    private static final Lock readLock = readWriteLock.readLock();
    
     static ExecutorService executeIt = Executors.newFixedThreadPool(2);
     static int ID = 0;
     static String[] Buffers = new String[3];
     static boolean test = false;

    public App(boolean nottest) throws InterruptedException {
         
        // стартуем сервер на порту 1234 и инициализируем переменную для обработки консольных команд с самого сервера
            try (ServerSocket server = new ServerSocket(1234);
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            System.out.println("Server initialization...");

            // стартуем цикл при условии что серверный сокет не закрыт
            while (!server.isClosed()) {
                if(ID == 2)
                    break;
                
                // если комманд от сервера нет то становимся в ожидание
                // подключения к сокету общения под именем - "clientDialog" на
                // серверной стороне
                Socket client = server.accept();

                // после получения запроса на подключение сервер создаёт сокет
                // для общения с клиентом и отправляет его в отдельную нить
                // в Runnable(при необходимости можно создать Callable)
                // монопоточную нить = сервер - MonoThreadClientHandler и тот
                // продолжает общение от лица сервера
                executeIt.execute(new MonoThreadClientHandler(client, ++ID, Buffers));
                System.out.println("VideoCam connection detected. ID = " + Integer.toString(ID));
            }
            
            System.out.println("Server started");
            // for testability
            test = true;
            
            if(nottest)
                while(true)
                {
                    // проверяем поступившие комманды из консоли сервера
                    if (br.ready()) { 
                        String cmdFromCLI = br.readLine();
                        if (cmdFromCLI.contains("show ")) {
                            char showID = cmdFromCLI.charAt(cmdFromCLI.indexOf("show ") + 5);
                            System.out.println("Server initiate showing VideoCAM #" + showID + " ...");
                            System.out.println("VideoStream:");
                            System.out.println();
                            int show = Character.getNumericValue(showID);
                            for(int i = 0; i < 10; i++)
                            {
                                Thread.sleep(500);
                                readLock.lock();
                                try {
                                    System.out.println(Buffers[show]);
                                } finally {
                                    readLock.unlock();
                                }
                            }
                            System.out.println();

                        } else if (cmdFromCLI.contains("quit")) {
                            System.out.println("Main Server initiate exiting...");
                            server.close();
                            break;
                        }
                    }
                }

            // закрытие пула нитей после завершения работы всех нитей
           executeIt.shutdownNow();
        } catch (IOException e) {
        }
    }

    
    public static void main( String[] args ) throws InterruptedException
    {
        App app = new App(true);
    }
    
    public static boolean isTest() {
        return test;
    }
}
