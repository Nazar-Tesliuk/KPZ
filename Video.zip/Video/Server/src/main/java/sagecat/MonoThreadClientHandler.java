package sagecat;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
enum STAGE {
    WAIT,
    ASK,
    STREAM,
    END
}

/**
 * Mono server (helps to create MultiThreadServer in App.java
 *
 * @author sagecat
 */
public class MonoThreadClientHandler implements Runnable {

    private static Socket clientDialog;
    
    private static final ReadWriteLock readWriteLock = new ReentrantReadWriteLock();
    private static final Lock writeLock = readWriteLock.writeLock();

    private static STAGE currentStage;
    private static int ID;
    private static String[] VideoBuffer;

    public MonoThreadClientHandler(Socket client, int ID, String[] Buffers) {
        MonoThreadClientHandler.clientDialog = client;
        currentStage = STAGE.WAIT;
        MonoThreadClientHandler.setID(ID);
        VideoBuffer = Buffers;
        VideoBuffer[ID] = "VideoCam is not ready...";
    }

    @Override
    public void run() {

        try {
            // канал чтения из сокета
            try ( // инициируем каналы общения в сокете, для сервера
            // канал записи в сокет следует инициализировать сначала канал чтения для избежания блокировки выполнения программы на ожидании заголовка в сокете
                    DataOutputStream out = new DataOutputStream(clientDialog.getOutputStream()); // канал чтения из сокета
                    DataInputStream in = new DataInputStream(clientDialog.getInputStream())) {
                
                ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                // основная рабочая часть //
                //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                // начинаем диалог с подключенным клиентом в цикле, пока сокет не
                // закрыт клиентом
                while (!clientDialog.isClosed()) {
                    // серверная нить ждёт в канале чтения (inputstream) получения
                    // данных клиента после получения данных считывает их
                    String entry = in.readUTF();
                    
                    if (entry.equalsIgnoreCase("client:ask:") && currentStage == STAGE.WAIT) {
                        out.writeUTF("server:rdy:");
                        currentStage = STAGE.ASK;
                    } else if (entry.equalsIgnoreCase("client:start:") && currentStage == STAGE.ASK) {
                        currentStage = STAGE.STREAM;
                    } else if (entry.equalsIgnoreCase("client:stop:") && currentStage == STAGE.STREAM) {
                        currentStage = STAGE.END;
                        out.writeUTF("Server:end:");
                        break;
                    }
                    else if(currentStage == STAGE.STREAM){
                        Thread.sleep(500);
                        writeLock.lock();
                        try {
                            MonoThreadClientHandler.VideoBuffer[ID] = entry;
                        } finally {
                            writeLock.unlock();
                        }
                    }
                    else{
                    } // якщо ми отримали щось непонятне, то пофіг - працюємо далі, не змінюючи стадію
                    
                    // освобождаем буфер сетевых сообщений
                    out.flush();
                    
                    // возвращаемся в началло для считывания нового сообщения
                }
                
                ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                // основная рабочая часть //
                //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                // если условие выхода - верно выключаем соединения
                System.out.println("Client with [ID = " + Integer.toString(ID) + "] is disconnected");
                
            }

            // потом закрываем сокет общения с клиентом в нити моносервера
            clientDialog.close();

            System.out.println("Closing connections & channels - DONE.");
        } catch (IOException e) {
        } catch (InterruptedException ex) {
            Logger.getLogger(MonoThreadClientHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void setID(int ID) {
        MonoThreadClientHandler.ID = ID;
    }
}
