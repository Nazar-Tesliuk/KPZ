package sagecat;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

enum STAGE
{
    WAIT,
    ASK,
    STREAM,
    END
}

/**
 * Client app for a VideoSurveillanceApp
 *
 */
public class App 
{
    private static STAGE currentStage = STAGE.WAIT;
    
    /**
     * 
     * @param args
     * @throws InterruptedException
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws InterruptedException, IOException {

        // запускаем подключение сокета по известным координатам и нициализируем приём сообщений с консоли клиента      
        try(Socket socket = new Socket("localhost", 1234);  
                DataOutputStream oos = new DataOutputStream(socket.getOutputStream());
                DataInputStream ois = new DataInputStream(socket.getInputStream()); )
        {

            System.out.println("Client connected to socket.");
            System.out.println();
                        
                String entry = "";
                // проверяем живой ли канал и работаем если живой           
                while(!socket.isOutputShutdown()){
                    
                        // Запуск
                        if(currentStage == STAGE.WAIT) {
                            oos.writeUTF("client:ask:");
                            oos.flush();
                            System.out.println("Clien sent message <client:ask:> to server.");
                            currentStage = STAGE.ASK;
                            
                            // ждем шо, ж нам на цю фігню відповість сервер
                            entry = ois.readUTF();
                            
                        } else if(entry.contains("server:rdy:") && currentStage == STAGE.ASK){
                              oos.writeUTF("client:start:");
                              oos.flush();
                              System.out.println("Clien sent message <client:start:> to server.");
                              currentStage = STAGE.STREAM;

                              
                              // TODO change if norm work will be needed
                              System.out.println("Пішов флуд: ");
                              for(int i = 0; i < 180; i++) // флуд на протязі 180 * 0.5 = 90 (секунд) = 1,5 (хв)
                              {
                                  Thread.sleep(500);
                                  System.out.println("VideoFrame #" + Integer.toString(i));
                                  oos.writeUTF("VideoFrame #" + Integer.toString(i));
                                  oos.flush();
                              }
                              
                              // пофлудили трохи і досить
                              currentStage = STAGE.END;
                              oos.writeUTF("client:stop:");
                              break;
                              
                         }
                        else{
                        } // отримали шось непонятне - нічого не робимо     
                     }
                }
            // на выходе из цикла общения закрываем свои ресурсы
            System.out.println("Closing connections & channels on clentSide - DONE.");
    }
}
