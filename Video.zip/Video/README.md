# VideoSurveillanceApp

**The project** was created for training purposes.

**Main goal** is to help me get better acquainted with the technologies and basic principles of enterprise software development using Java as an example.
